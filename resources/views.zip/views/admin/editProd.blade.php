
<!doctype html>
<html lang="en">

<head>
	<title>FAM</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<!-- VENDOR CSS -->
	<link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/vendor/linearicons/style.css">
	<link rel="stylesheet" href="assets/vendor/chartist/css/chartist-custom.css">
	<!-- MAIN CSS -->
	<link rel="stylesheet" href="assets/css/main.css">
	<!-- FOR DEMO PURPOSES ONLY. You should remove this in your project -->
	<link rel="stylesheet" href="assets/css/demo.css">
	<!-- GOOGLE FONTS -->
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700" rel="stylesheet">
	<!-- ICONS -->
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
</head>

<body>

<div class="panel-group">
    <div class="panel panel-default">
        <div class="panel-heading">
        <div>Edit Product
        <a href="/viewP" type="button" class="btn btn-danger" style="float: right;">
         Close
        </a>
</div>
         </div>
        <div class="panel-body">
            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="col-md-12">
                        <div class="card">
                        

                        <form method="POST" action="{{URL::to('/productUpdate',$records->id) }}" enctype="multipart/form-data" id="edit">
                        @csrf

                        <div class="form-group " style="padding-left: 10px;padding-top: 5px;padding-right: 10px;">
                            <label for="name" class="col-form-label text-md-right">{{ __('Product Name') }}</label>

                            <div>
                                <input id="name" type="text" value="{{$records->name}}" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>

                                @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
                        


                        <div class="form-group " style="padding-left: 10px;padding-right: 10px;">
                            <label for="product_code" class="col-form-label text-md-right">{{ __('Product Code') }}</label>

                            <div>
                                <input id="product_code" type="text" value="{{$records->code}}" class="form-control @error('product_code') is-invalid @enderror" name="product_code" value="{{ old('product_code') }}" required autocomplete="product_code" autofocus>

                                @error('product_code')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
 

                        <div class="form-group " style="padding-left: 10px;padding-right: 10px;">
                            <label for="product_color" class="col-form-label text-md-right">{{ __('Product Color') }}</label>

                            <div >
                                <input id="product_color" type="text" value="{{$records->color}}" class="form-control @error('product_color') is-invalid @enderror" name="product_color" value="{{ old('product_color') }}" required autocomplete="product_color" autofocus>

                                @error('product_color')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group " style="padding-left: 10px;padding-right: 10px;">
                            <label for="product_description" class="col-form-label text-md-right">{{ __('Product Description') }}</label>

                            <div>
                                <textarea name="product_description" id="product_description" class="form-control @error('product_description') is-invalid @enderror" value="{{ old('product_description') }}">{{$records->description}}</textarea>
                                @error('product_description')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group " style="padding-left: 10px;padding-right: 10px;">
                            <label for="product_price" class="col-form-label text-md-right">{{ __('Product Price') }}</label>

                            <div>
                                <input id="product_price" type="text" value="{{$records->price}}" class="form-control" name="product_price" required autocomplete="product_price">
                            </div>
                        </div>

                        <div class="form-group" style="padding-left: 10px;padding-right: 10px;">
                            <label for="image" class="col-form-label text-md-right">{{ __('Picture Upload') }}</label>

                            <div>
                                <input id="image" type="file"  class="form-control @error('image') is-invalid @enderror" name="image" required autocomplete="image">
                                <input type="hidden" value="{{$records->image}} "name="old_image">
                                @error('image')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
                        <div>
                        <img src="{{ asset('uploads/products/' . $records->image) }}" alt="" width="80px" height="50px">
                        </div>

                        <div class="form-group row mb-0" style="padding-left: 45%;padding-top: 20px;" >
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary" style="background-color:#62c2e4 ;">
                                    {{ __('Update') }}
                                </button>
                            </div>
                        </div>
                    </form>

            </div>
                        </div>
                    </div>
                </div>
            </div>



        </div>
    </div>

   
    <script src="assets/vendor/jquery/jquery.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/vendor/jquery.easy-pie-chart/jquery.easypiechart.min.js"></script>
	<script src="assets/vendor/chartist/js/chartist.min.js"></script>
	<script src="assets/scripts/klorofil-common.js"></script>
</body>

</html>
