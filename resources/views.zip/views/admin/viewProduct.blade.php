@extends('admin.home')
@section('body')

<div class="modal fade" id="producteditmodal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editmodal">Edit Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
    </div>
  </div>
</div>
<!-- view description -->
<div class="modal fade" id="productviewmodal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="viewmodal">Message</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
    </div>
  </div>
</div>
<!-- DELETE -->
<div class="modal fade" id="productdeletemodal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editmodal">Delete Product</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div>
        <h1 class="modal-title">Are you serious, You need to move this product????</h1>
      </div>
      <div style="padding-bottom: 10px;padding-right: 10px;padding-left: 10px;">
        <a href="#" type="button" class="btn btn-danger">OK</a>
        <a href="/viewP" type="button" class="btn btn-success" style="float: right;">Cancel</a>
      </div>
    </div>
  </div>
</div>
<!-- END OF DELETE -->
<div class="panel panel-headline">
  <div class="panel-heading">
    <h3 class="panel-title" style="padding-left: 45%;">Products View</h3>
    <div class="right">
      <button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
    </div>
  </div>
  @if(Session::has('flash_message_success'))
  <div class="alert alert-sm alert-danger alert-block" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
    <strong>{!! session('flash_message_success')!!}</strong>
  </div>
  @endif
  <div class="panel-body">


    <table class="table table-bordered table-hover table-striped tablesorter" id="emp" style="text-align: center;">
      <thead>
        <tr>
          <th>ID<i class="fa fa-sort"></i></th>
          <th>PRODUCT IMAGE<i class="fa fa-sort"></i></th>
          <th>PROD NAME<i class="fa fa-sort"></i></th>
          <th>PROD CODE<i class="fa fa-sort"></i></th>
          <th>PROD COLOR<i class="fa fa-sort"></i></th>
          <th>PROD DESCRIPTION<i class="fa fa-sort"></i></th>
          <th>PRODUCT PRICE<i class="fa fa-sort"></i></th>
          <th>ACTION <i class="fa fa-sort"></i></th>
        </tr>
      </thead>
      <tbody>
        @foreach($viewproduct as $key => $stud)
        <tr>
          <td>{{++$key}}</td>
          <td><img src="{{ asset('uploads/products/' . $stud->image) }}" alt="" width="80px" height="50px"></td>
          <td>{{$stud->name}}</td>
          <td>{{$stud->code}}</td>
          <td>{{$stud->color}}</td>
          <td><a href="{{route('descriptionView',$stud->id)}}" class="btn btn-primary deletebtn" data-toggle="modal" data-target="#productviewmodal">View</a></td>
          <td>{{$stud->price}}</td>
          <td>
            <a href="{{route('productEdit',$stud->id)}}" class="btn btn-primary deletebtn" data-toggle="modal" data-target="#producteditmodal">EDIT</a>
            <a href="{{route('productDel',$stud->id)}}" class="btn btn-danger deletebtn" data-toggle="modal" data-target="#productdeletemodal">DELETE</a>
          </td>
        </tr>
        @endforeach

      </tbody>
    </table>
  </div>
</div>

@endSection