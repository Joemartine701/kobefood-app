
<!doctype html>
<html lang="en">

<head>
	<title>FAM</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<!-- VENDOR CSS -->
	<link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/vendor/linearicons/style.css">
	<link rel="stylesheet" href="assets/vendor/chartist/css/chartist-custom.css">
	<!-- MAIN CSS -->
	<link rel="stylesheet" href="assets/css/main.css">
	<!-- FOR DEMO PURPOSES ONLY. You should remove this in your project -->
	<link rel="stylesheet" href="assets/css/demo.css">
	<!-- GOOGLE FONTS -->
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700" rel="stylesheet">
	<!-- ICONS -->
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon.png">
</head>

<body>

<div class="panel-group">
    <div class="panel panel-default">
        <div class="panel-heading">
        <div>Edit Product
        <a href="/viewgallery" type="button" class="btn btn-danger" style="float: right;">
         Close
        </a>
</div>
         </div>
        <div class="panel-body">
            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="col-md-12">
                        <div class="card">
                        

                        <form method="POST" action="{{URL::to('/galleryUpdate',$records->id) }}" enctype="multipart/form-data" id="edit">
                        @csrf

                        <div class="form-group " style="padding-left: 10px;padding-top: 5px;padding-right: 10px;">
                            <label for="name" class="col-form-label text-md-right">{{ __('Gallery Name') }}</label>

                            <div>
                                <input id="name" type="text" value="{{$records->name}}" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>

                                @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
                        <div class="form-group" style="padding-left: 10px;padding-right: 10px;">
                            <label for="image" class="col-form-label text-md-right">{{ __('Picture Upload') }}</label>

                            <div>
                                <input id="image" type="file"  class="form-control @error('image') is-invalid @enderror" name="image" required autocomplete="image">
                                <input type="hidden" value="{{$records->image}} "name="old_image">
                                @error('image')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
                        <div>
                        <img src="{{ asset('uploads/products/' . $records->image) }}" alt="" width="80px" height="50px">
                        </div>

                        <div class="form-group row mb-0" style="padding-left: 45%;padding-top: 20px;" >
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary" style="background-color:#62c2e4 ;">
                                    {{ __('Update') }}
                                </button>
                            </div>
                        </div>
                    </form>

            </div>
                        </div>
                    </div>
                </div>
            </div>



        </div>
    </div>

   
    <script src="assets/vendor/jquery/jquery.min.js"></script>
	<script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js"></script>
	<script src="assets/vendor/jquery.easy-pie-chart/jquery.easypiechart.min.js"></script>
	<script src="assets/vendor/chartist/js/chartist.min.js"></script>
	<script src="assets/scripts/klorofil-common.js"></script>
</body>

</html>
