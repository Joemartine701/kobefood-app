@extends('welcome')
<style>
	.small-img-group {
		display: flex;
		justify-content: space-between;
	}

	.small-img-col {
		flex-basis: 24%;
		cursor: pointer;
	}

	.product {
		cursor: pointer;
		margin-bottom: 2rem;
	}

	.product img {
		transition: 0.3s all;
	}

	.product:hover img {
		opacity: 0.7;
	}

	.product .buy-btn {
		background: #fb774b;
		transform: translateY(20px);
		opacity: 0;
		transition: 0.3s all;
	}

	.product:hover .buy-btn {
		transform: translateY(0);
		opacity: 1;

	}

	hr {
		width: 30px;
		height: 2px;
		background-color: #fb774b;
	}

	.star i {
		font-size: 0.8rem;
		color: goldenrod;
	}
</style>
@section('body')

<!-- Start Gallery -->
<!-- <div id="gallery" class="gallery-box read-more-container">
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-12">
					<div class="title-box">
						<h2>Products</h2>
						<p>Angalia bidhaa zinazopatikana kwenye kampuni yetu na uagize, chagua ipi wahitaji  tuwasiliane.</p>
					</div>
				</div>
			</div>
			
			<div class="popup-gallery row clearfix">

			@foreach($product as $result)

			<div class="col-md-2 ">
              <div class="card mb-2 box-shadow box-gallery">
                <img class="card-img-top " src="{{ asset('uploads/products/' . $result->image) }}" alt="Card image cap">
			    <div class="card-body">
                <p class="card-text"></p>
                  <div class="d-flex justify-content-between align-items-center">
                    <div class="btn-group">
					 <div class="contain">
					 <p>{{$result->name}}   Tshs. {{$result->price}}</p>
					 <p>
					 <span class="read-more-text">{{$result->description}}</span>
					 </p>
					 <span class="read-more-btn">Read More...</span>
					 </div>
                    </div>
                    <br><br>
                    <small class="text-muted"></small>
                  </div>
                    
                </div>
              </div>
            </div>
				@endforeach
			</div>
		</div>
	</div>
    <!-- End Gallery -->
<!-- <script>
      const parentContainer = document.querySelector('.read-more-container');
	  parentContainer.addEventListener('click',event=>{
		  const current = event.target;
		  const isReadMoreBtn = current.className.includes('read-more-btn');
		  if(!isReadMoreBtn)return;
		  const currentText = event.target.parentNode.querySelector('.read-more-text');
		  currentText.classList.toggle('read-more-text--show');
		  current.textContent = current.textContent.includes('Read More')? "Read Less..." : "Read More...";

	  })
	</script>	
<div class="container">
<div class="row">


</div> -->

<!-- </div> -->



<!-- <div class="wra">

	<div class="product-img">
		<img src="images/f1.png" alt="" height="420" width="327">
	</div>
	<div class="product-info">
		<div class="product-text">
			<h1>xdrtyuyfuuigugiohi</h1>
			<h2>xrfydtudfyifuigf</h2>
            <p></p>
		</div>
	</div>
	<div class="product-price-btn">
		<p><span>78</span>$</p>
		<button type="button">Buy Now</button>
	</div>
	</div> -->

<section class=" container product my-5 pt-5">

	<div class="row mt-5">
		<div class="col-lg-5 col-md-12 col-12 ">
			<img class="img-fluid w-100 pb-1" src="images/f1.png" id="MainImg" alt="">
			<div class="small-img-group">
				<div class="small-img-col">
					<img src="images/f2.png" width="100%" class="small-img" alt="">
				</div>
				<div class="small-img-col">
					<img src="images/f2.png" width="100%" class="small-img" alt="">
				</div>
				<div class="small-img-col">
					<img src="images/f2.png" width="100%" class="small-img" alt="">
				</div>
				<div class="small-img-col">
					<img src="images/f2.png" width="100%" class="small-img" alt="">
				</div>
			</div>
		</div>
		<div class="col-lg-6 col-md-12 col-12">
			<h6>Biometric Products</h6>
			<h3>Medical and Family</h3>
			<h2 id="pric">$500</h2>
			<h4 class="mt-2 mb-2">Product Details</h4>
			<span id="description">ydtgweu8yqwe8udyhq8dyhq8dyd8wudhuqwedwubhdcwcwcwcu hasbcdshgcdsugcdsugcdsuidsuid scdbwsdbuidgq
				schsgudg shcbsbq hcbywhvcwugcwcdgwhweywegfwe xcgcgdfyudggyudgyufvwevfwevyvwww dcbwhcv</span>
		</div>
	</div>
</section>

<section id="featured" class="my-5 pb-5">

	<div class="container text-center col-log-3 col-md-4 col-12">
		<h3>Related Products</h3>
		<hr class="mx-auto">
		<p>dhdhwedwehdwhdwhdwdnwdhdhwdh</p>
	</div>

	<div class="row mx-auto container-fluid">
	@foreach($product as $result)
		<div class="product text-center col-lg-3 col-md-4 col-12">
			<img class="img-fluid mb-3 prod" src="{{ asset('uploads/products/' . $result->image) }}" alt="">
			<div class="star">
				<i class="fa fa-star" aria-hidden="true"></i>
				<i class="fa fa-star" aria-hidden="true"></i>
				<i class="fa fa-star" aria-hidden="true"></i>
				<i class="fa fa-star" aria-hidden="true"></i>
				<i class="fa fa-star" aria-hidden="true"></i>
			</div>
			<h5 class="p-name">{{$result->name}} </h5>
			<h4 class="p-price">Tshs. {{$result->price}}</h4>
			<span class="read-more-text" type="hidden">{{$result->description}}</span>
			<button class="buy-btn" onclick="after()">Buy Now</button>
		</div>
		@endforeach
	</div>
	
</section>


<script>
	var MainImg = document.getElementById('MainImg');
	var smalling = document.getElementsByClassName('small-img');
	smalling[0].onclick = function() {
		MainImg.src = smalling[0].src;

	}
	var x="";
	var prod = document.getElementsByClassName('prod')
	var descr = document.getElementsByClassName('read-more-text');
	var price = document.getElementsByClassName('p-price');
    
function after(){
	console.log(x);
	     document.getElementById('MainImg')
        .src=prod[1].src;
        document.getElementById('description')
        .innerHTML=descr[1];
		// document.getElementById('pric')
        // .innerHTML = span.;
}
</script>
@endsection