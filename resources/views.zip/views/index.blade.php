@extends('welcome')
@section('body')

<!-- Start Banner -->
<div class="ulockd-home-slider">
    <div class="container-fluid">
        <div class="row">
            <div class="pogoSlider" id="js-main-slider">
                <div class="pogoSlider-slide" data-transition="fade" data-duration="1500" style="background-image:url(images/slider-01.jpg);">
                    <div class="lbox-caption pogoSlider-slide-element">
                        <div class="lbox-details">
                            <h1>Welcome to FAM</h1>
                            <p>Fusce convallis ante id purus sagittis malesuada. Sed erat ipsum </p>
                            <a href="/services" class="btn">Services</a>
                        </div>
                    </div>
                </div>
                <div class="pogoSlider-slide" data-transition="fade" data-duration="1500" style="background-image:url(images/slider-02.jpg);">
                    <div class="lbox-caption pogoSlider-slide-element">
                        <div class="lbox-details">
                            <h1>We are Expert in The Field of Medical Engineering and Family</h1>
                            <p>Fusce convallis ante id purus sagittis malesuada. Sed erat ipsum</p>
                            <a href="/aboutUs" class="btn">About Us</a>
                        </div>
                    </div>
                </div>
                <div class="pogoSlider-slide" data-transition="fade" data-duration="1500" style="background-image:url(images/fam4.jpg);">
                    <div class="lbox-caption pogoSlider-slide-element">
                        <div class="lbox-details">
                            <h1>Welcome to FAM website </h1>
                            <p>Fusce convallis ante id purus sagittis malesuada. Sed erat ipsum </p>
                            <a href="/contactUs" class="btn">Contact Us</a>
                        </div>
                    </div>

                </div>
            </div><!-- .pogoSlider -->
        </div>
    </div>
</div>
<!-- End Banner -->


<!-- Start Appointment -->
{{-- <div id="appointment" class="appointment-main">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="title-box">
						<h2>Appointment</h2>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-6 col-md-6">
					<div class="well-block">
                        <div class="well-title">
                            <h2>Book an Appointment</h2>
                        </div>
                        <form>
                            <!-- Form start -->
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label" for="name">Name</label>
                                        <input id="name" name="name" type="text" placeholder="Name" class="form-control input-md">
                                    </div>
                                </div>
                                <!-- Text input-->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label" for="email">Email</label>
                                        <input id="email" name="email" type="text" placeholder="E-Mail" class="form-control input-md">
                                    </div>
                                </div>
                                <!-- Text input-->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label" for="date">Preferred Date</label>
                                        <input id="date" name="date" type="text" placeholder="Preferred Date" class="form-control input-md">
                                    </div>
                                </div>
                                <!-- Select Basic -->
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label" for="time">Preferred Time</label>
                                        <select id="time" name="time" class="form-control">
                                            <option value="8:00 to 9:00">8:00 to 9:00</option>
                                            <option value="9:00 to 10:00">9:00 to 10:00</option>
                                            <option value="10:00 to 1:00">10:00 to 1:00</option>
                                        </select>
                                    </div>
                                </div>
                                <!-- Select Basic -->
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="control-label" for="appointmentfor">Department</label>
                                        <select id="appointmentfor" name="appointmentfor" class="form-control">
                                            <option value="Choose Department">Choose Department</option>
											<option value="Gynacology">Gynacology</option>
											<option value="Dermatologist">Dermatologist</option>
											<option value="Orthology">Orthology</option>
											<option value="Anesthesiology">Anesthesiology</option>
											<option value="Ayurvedic">Ayurvedic</option>
                                        </select>
                                    </div>
                                </div>
                                <!-- Button -->
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <button id="singlebutton" name="singlebutton" class="new-btn-d br-2">Make An Appointment</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <!-- form end -->
                    </div>
				</div>
				<div class="col-lg-6 col-md-6">
					<div class="well-block">
                        <div class="well-title">
                            <h2>Why Appointment with Us</h2>
                        </div>
                        <div class="feature-block">
                            <div class="feature feature-blurb-text">
                                <h4 class="feature-title">24/7 Hours Available</h4>
                                <div class="feature-content">
                                    <p>Integer nec nisi sed mi hendrerit mattis. Vestibulum mi nunc, ultricies quis vehicula et, iaculis in magnestibulum.</p>
                                </div>
                            </div>
                            <div class="feature feature-blurb-text">
                                <h4 class="feature-title">Experienced Staff Available</h4>
                                <div class="feature-content">
                                    <p>Aliquam sit amet mi eu libero fermentum bibendum pulvinar a turpis. Vestibulum quis feugiat risus. </p>
                                </div>
                            </div>
                            <div class="feature feature-blurb-text">
                                <h4 class="feature-title">Low Price & Fees</h4>
                                <div class="feature-content">
                                    <p>Praesent eu sollicitudin nunc. Cras malesuada vel nisi consequat pretium. Integer auctor elementum nulla suscipit in.</p>
                                </div>
                            </div>
                        </div>
                    </div>
				</div>
			</div>
		</div>
	</div>  --}}
<!-- End Appointment -->

<!-- Start Gallery -->

<div id="maintainance" class="services-bo">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="title-box">
                    <h2>Gallery</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="owl-carousel owl-theme">
                @foreach($viewgallery as $gallery)
                    <div class="item">
                   
                        <div id="gallery" class="gallery-box">
                            <div class="container-fluid">
                                <div class="popup-gallery row clearfix ">     
                                            
                                                <div class="box-gallery ">

                                                    <div><img src="{{ asset('uploads/products/' . $gallery->image) }}" alt=""></div>

                                                    <div class="box-content">
                                                        <h3 class="title">{{$gallery->name}}</h3>
                                                        <ul class="icon">
                                                            <li><a href="{{ asset('uploads/products/' . $gallery->image) }}"><i class="fa fa-picture-o" aria-hidden="true"></i></a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                </div>

                            </div>
                        </div>
                        
                    </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<!-- <div id="gallery" class="gallery-box">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="title-box">
                    <h2>Gallery</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
                </div>
            </div>
        </div>


        <div class="main">
                    <div class="popup-gallery row clearfix ">
                    <div class="containe">

<div class="slider" id="sld">
@foreach($viewgallery as $gallery)
                        <div class="col-md-3 col-sm-6 box ">
                            <div class="box-gallery ">

                                <div><img src="{{ asset('uploads/products/' . $gallery->image) }}" alt=""></div>

                                <div class="box-content">
                                    <h3 class="title">{{$gallery->name}}</h3>
                                    <ul class="icon">
                                        <li><a href="{{ asset('uploads/products/' . $gallery->image) }}"><i class="fa fa-picture-o" aria-hidden="true"></i></a></li>
                                    </ul>
                                </div>
                            </div>


                        
                        </div>
                        @endforeach
                        
              </div>
        </div>

        <span class="nav previous" onclick="fPrevious()"> < </span>
                <span class="nav next" onclick="fNext()">></span>
                    </div>

                </div>


</div>
</div>
</div> -->

<!-- End Gallery -->

<div id="contact" class="contact-box">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-xs-12">
                <div class="left-contact">
                    <h2>CONTACT</h2>
                    <div class="media cont-line">
                        <div class="media-left icon-b">
                            <i class="fa fa-volume-control-phone" aria-hidden="true"></i>
                        </div>
                        <div class="media-body dit-right">
                            <h4>Phone Number</h4>
                            <a href="#">+255 787 022 047</a><br>
                            <a href="#">+255 712 333 220</a>
                        </div>
                    </div>
                </div>
                <div class="media cont-line">
                    <div class="media-left icon-b">
                        <i class="fa fa-envelope" aria-hidden="true"></i>
                    </div>
                    <div class="media-body dit-right">
                        <h4>Email</h4>
                        <a href="#">frank.meena@gmail.com</a>
                        <a href="#">info@famengineering.com</a><br>
                    </div>
                </div>

                <div class="media cont-line">
                    <div class="media-left icon-b">
                        <i class="fa fa-location-arrow" aria-hidden="true"></i>
                    </div>
                    <div class="media-body dit-right">
                        <h4>Location</h4>
                        <p>P.O.BOX 00000</p>
                        <p>Mbezi Mwisho Msakuzi <br> Dar es Salaam,Tanzania</p>
                    </div>
                </div>


            </div>


        </div>
    </div>

    <!-- Start Team -->
    {{-- <div id="team" class="team-box">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="title-box">
						<h2>Our Doctor</h2>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
					</div>
				</div>
			</div>
			
			<div class="row">
                <div class="col-md-4 col-sm-6">
                    <div class="our-team">
                        <div class="pic">
                            <img src="images/img-1.jpg" alt="">
                        </div>
                        <div class="team-content">
                            <h3 class="title">Williamson</h3>
                            <span class="post">web developer</span>
                            <ul class="social">
                                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 col-sm-6">
                    <div class="our-team">
                        <div class="pic">
                            <img src="images/img-2.jpg" alt="">
                        </div>
                        <div class="team-content">
                            <h3 class="title">kristina</h3>
                            <span class="post">Web Designer</span>
                            <ul class="social">
                                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 col-sm-6">
                    <div class="our-team">
                        <div class="pic">
                            <img src="images/img-3.jpg" alt="">
                        </div>
                        <div class="team-content">
                            <h3 class="title">Steve Thomas</h3>
                            <span class="post">web developer</span>
                            <ul class="social">
                                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
			
		</div>
	</div>  --}}

    <!-- End Team -->

    <!-- Start Blog -->
    {{-- <div id="blog" class="blog-box">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="title-box">
						<h2>Blog</h2>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-4 col-md-6 col-sm-12">
					<div class="blog-inner">
						<div class="blog-img">
							<img class="img-fluid" src="images/blog-img-01.jpg" alt="" />
						</div>
						<div class="item-meta">
							<a href="#"><i class="fa fa-comments-o"></i> 5 Comment </a>
							<a href="#"><i class="fa fa-user-o"></i> Admin</a>
							<span class="dti">25 July 2018</span>
						</div>
						<h2>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</h2>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard </p>
						<a class="new-btn-d br-2" href="#">Read More <i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-sm-12">
					<div class="blog-inner">
						<div class="blog-img">
							<img class="img-fluid" src="images/blog-img-02.jpg" alt="" />
						</div>
						<div class="item-meta">
							<a href="#"><i class="fa fa-comments-o"></i> 5 Comment </a>
							<a href="#"><i class="fa fa-user-o"></i> Admin</a>
							<span class="dti">25 July 2018</span>
						</div>
						<h2>Proin vel sem ut lorem rhoncus lacinia. </h2>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard </p>
						<a class="new-btn-d br-2" href="#">Read More <i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-sm-12">
					<div class="blog-inner">
						<div class="blog-img">
							<img class="img-fluid" src="images/blog-img-03.jpg" alt="" />
						</div>
						<div class="item-meta">
							<a href="#"><i class="fa fa-comments-o"></i> 5 Comment </a>
							<a href="#"><i class="fa fa-user-o"></i> Admin</a>
							<span class="dti">25 July 2018</span>
						</div>
						<h2>Aliquam egestas magna a malesuada rutrum. </h2>
						<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard </p>
						<a class="new-btn-d br-2" href="#">Read More <i class="fa fa-angle-double-right" aria-hidden="true"></i></a>
					</div>
				</div>
			</div>
		</div>
	</div>  --}}
    <script>
        var showed_box = 0;

        function fNext() {

            showed_box += -500;

            if (showed_box < -2000)
                showed_box = 0;

            document.getElementById('sld').style.transform = "translateX(" + showed_box + "px)";
        }

        function fPrevious() {

            showed_box += 500;

            if (showed_box > 0)
                showed_box = -2000;

            document.getElementById('sld').style.transform = "translateX(" + showed_box + "px)";

        }
    </script>


    @endsection