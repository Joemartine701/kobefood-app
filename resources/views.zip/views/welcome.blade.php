<!DOCTYPE html>
<html lang="en">
<!-- Basic -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <!-- Site Metas -->
    <title>{{ config('app.name', 'FAM') }}</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Pogo Slider CSS -->
    <link rel="stylesheet" href="css/pogo-slider.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">


</head>

<body id="home" data-spy="scroll" data-target="#navbar-wd" data-offset="98">

    <!-- LOADER -->
    <!-- <div id="preloader">
		<div class="loader">
			<img src="images/preloader.gif" alt="" />
		</div>
    </div>end loader -->
    <!-- END LOADER -->

    <!-- Start top bar -->
    <div class="main-top">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="left-top">
                        {{-- <a class="new-btn-d br-2" href="#"><span>Book Appointment</span></a>
						<div class="mail-b"><a href="#"><i class="fa fa-envelope-o" aria-hidden="true"></i> demo@gmail.com</a></div>  --}}
                        <div class=" new-btn-d br-2" id="demo">
                            <h5 class="bold text-left" id="date" style="font-size: 15px;font-weight: 600;"></h5>
                            <h5 class="bold text-left" id="time" style="font-size: 15px;font-weight: 600;"></h5>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="wel-nots">
                        <div class="row no-gutters mt-3 align-items-center">
                            <div class="col-10">
                                <input class="form-control border-secondary rounded-pill pr-5" type="search" value="search" id="example-search-input2">
                            </div>
                            <div class="col-auto">
                                <button class="btn text-dark border-0 rounded-pill ml-n5" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- End top bar -->

    <!-- Start header -->
    <header class="top-header">
        <nav class="navbar header-nav navbar-expand-lg">
            <div class="container">
                <a class="navbar-brand" href="index.html"><img src="images/logo4.png" alt="image"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-wd" aria-controls="navbar-wd" aria-expanded="false" aria-label="Toggle navigation">
                    <span></span>
                    <span></span>
                    <span></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbar-wd">
                    <ul class="navbar-nav">
                        <li><a class="nav-link active" href="/">Home</a></li>
                        <li><a class="nav-link" href="#gallery">Gallery</a></li>
                        <li><a class="nav-link" href="#">SERVICES</a></li>
                        <li><a class="nav-link" href="/productAll">PRODUCTS</a></li>
                        <li><a class="nav-link" href="/aboutUs">ABOUT US</a></li>
                        <li><a class="nav-link" href="/contactUs">CONTACT US</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <!-- End header -->
    @yield('body')


    <div class="cont">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 col-md-4">
                    <div class="wow fadeInDown" data-wow-delay="0.1s">
                        <div class="widget">
                            <h4>VISITOR COUNTER</h4>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    Today
                                </div>
                                <div class="form-group col-md-4">
                                    5466
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    This Month
                                </div>
                                <div class="form-group col-md-4">
                                    5466
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-4">
                                    Total :
                                </div>
                                <div class="form-group col-md-4">
                                    5466
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="col-lg-4 col-md-2 col-sm-4 col-xs-12">
                    <div class="row">
                        <div class="service-time middle">
                            <h3>WORKING HOURS</h3>
                            <div class="time-table-section">
                                <ul>
                                    <li><span class="left">Monday - Friday</span><span class="right">8:00 – 18:00</span></li>
                                    <li><span class="left">Saturday</span><span class="right">8:00 – 16:00</span></li>
                                    <li><span class="left">Sunday</span><span class="right">8:00 – 13:00</span></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-sm-6 col-md-4">
                    <div class="wow fadeInDown" data-wow-delay="0.1s">
                        <div class="widget">
                            <h5>Follow us</h5>
                            <ul class="company-social">
                                <li class="social-facebook"><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li class="social-twitter"><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li class="social-google"><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                <li class="social-vimeo"><a href="#"><i class="fa fa-vimeo-square"></i></a></li>
                                <li class="social-dribble"><a href="#"><i class="fa fa-dribbble"></i></a></li>
                            </ul>
                            <div>
                            <h6>Phone numbers</h6>
                            <ul class="contact-social">
                            <div><li>+255 787 022 047<li></div>
                                        <li>+255 712 333 220</li>
                            </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Start Footer -->
    <footer class="footer-box">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <p class="footer-company-name">All Rights Reserved. &copy; 2021 <a href="#">FAM</a> Design By : <a href="#">FAM IT</a></p>
                </div>
            </div>
        </div>
    </footer>
    <!-- End Footer -->

    <a href="#" id="scroll-to-top" class="new-btn-d br-2"><i class="fa fa-angle-up"></i></a>

    <!-- ALL JS FILES -->
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/jquery.pogo-slider.min.js"></script>
    <script src="js/slider-index.js"></script>
    <script src="js/smoothscroll.js"></script>
    <script src="js/TweenMax.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
    <script src="js/isotope.min.js"></script>
    <script src="js/images-loded.min.js"></script>
    <script src="js/custom.js"></script>
    <script>
        // DATE AND TIME

        var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']; //array of days
        var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'] //array of months
        var date = new Date(); //creating Date object
        var currentDay = days[date.getDay()]; //determining day using the array and method 
        var currentMonth = months[date.getMonth()]; //determining month using the array and method
        var currentDate = date.getDate(); //current date
        var currentYear = date.getFullYear(); //current year
        document.getElementById('date').innerHTML = currentDay + ", " + currentMonth + " " + currentDate + ", " + currentYear + "</br";
        var hrs = date.getHours(),
            min = date.getMinutes(); //current time (hours and minutes)
        var suffix = 'AM';
        if (hrs >= 12) {
            hrs -= 12;
            suffix = 'PM';
        }
        if (hrs < 10) {
            hrs = "0" + hrs;
        }
        if (min < 10) {
            min = "0" + min;
        }
        document.getElementById('time').innerHTML = hrs + ": " + min + " " + suffix + "</br";

        // Visitor Counter

        // $(document).redy(function(){
        //     setInterval(function(){
        //         $.ajax({
        //             type:'post',
        //             url:'',
        //             data:{
        //                 get_online_visitor:"online_visitor",
        //             },
        //             success:function(response){
        //                 if(response!=""){
        //                     $("#online_visitor_val").html(response);
        //                 }
        //             }
        //         });
        //     },10000)
        // });
    </script>



</body>

</html>